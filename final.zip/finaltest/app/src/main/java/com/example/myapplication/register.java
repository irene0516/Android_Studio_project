package com.example.myapplication;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class register extends AppCompatActivity {
    static final String db_name="testDB";
    static final String tb_name="user";
    SQLiteDatabase db;
    EditText et1,et2,et3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        et1=(EditText)findViewById(R.id.editText1);
        et2=(EditText)findViewById(R.id.editText2);
        et3=(EditText)findViewById(R.id.editText3);
    }
    public void addData(String Username,String Password){
        ContentValues cv=new ContentValues(2);
        cv.put("Username",Username);
        cv.put("Password",Password);
        //db.insert(tb_name,null,cv);
        db.insertWithOnConflict(tb_name, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void Click(View v){
        if(et1.getText().toString().matches("")||et2.getText().toString().matches("")){
            Toast.makeText(this,"註冊失敗",Toast.LENGTH_SHORT).show();
        }else if(!(et3.getText().toString().matches(""))&&et2.getText().toString().equals(et3.getText().toString())){

            db=openOrCreateDatabase(db_name, Context.MODE_PRIVATE,null);
            addData(et1.getText().toString(),et2.getText().toString());
            db.close();
            Toast.makeText(this,"註冊成功",Toast.LENGTH_SHORT).show();
            finish();
        }else{
            Toast.makeText(this,"註冊失敗",Toast.LENGTH_SHORT).show();
        }
    }
    public void Goback(View v){
        finish();
    }
}
