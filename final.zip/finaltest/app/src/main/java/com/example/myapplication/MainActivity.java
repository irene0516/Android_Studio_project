package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
    EditText et1,et2;
    String account ="abc",passwd="123";
    static final String db_name="testDB";
    static final String tb_name="user";
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=openOrCreateDatabase(db_name, Context.MODE_PRIVATE,null);
        String createTable="CREATE TABLE IF NOT EXISTS "+tb_name+"(Username VARCHAR(64)unique,"+"Password VARCHAR(64))";
        db.execSQL(createTable);
        et1=(EditText)findViewById(R.id.editText1);
        et2=(EditText)findViewById(R.id.editText2);
        db.close();
    }
    public void clickOK(View v){
        String[] columns={};
        db=openOrCreateDatabase(db_name, Context.MODE_PRIVATE,null);
        Cursor cursor=db.query(tb_name,columns,null,null,null,null,null);
        int count=0;
        while(cursor.moveToNext()){
            String username=cursor.getString(0);
            String password=cursor.getString(1);
            if(username.equals(et1.getText().toString())&&password.equals(et2.getText().toString())){

                Intent it=new Intent(this, Page2.class);
                startActivity(it);
                count=count+1;
                break;
            }
        }
        if(count==1){
            Toast.makeText(this,"登入成功!",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this,"登入失敗!",Toast.LENGTH_SHORT).show();
        }
        db.close();

    }
    public void register(View v){

        //Toast.makeText(this,"登入成功!",Toast.LENGTH_SHORT).show();
        Intent it=new Intent(this,register.class);
        startActivity(it);
    }
}